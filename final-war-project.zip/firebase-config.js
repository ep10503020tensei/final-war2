// Firebase config
const firebaseConfig = {};